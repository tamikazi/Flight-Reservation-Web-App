class PassengerView {
    name: string;
    seat: string;

    constructor(name: string, seat: string) {
        this.name = name;
        this.seat = seat;
    }
}

export default PassengerView;