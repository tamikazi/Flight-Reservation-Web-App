export const ConfirmationPage = () => {
    return(
        <div className='container mt-5'>
            <p>Payment successful. Receipt and tickets will be emailed to you.</p>
        </div>
    );
};