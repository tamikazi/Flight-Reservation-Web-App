package com.ensf614.springflight.viewmodels;

import lombok.Data;


@Data
public class PassengerView {
    private String name;
    private String seatNumber;
}
