package com.ensf614.springflight.viewmodels;

import lombok.Data;

@Data
public class CrewView {
    private int userID;
    private int flightID;
    private String name;
}
