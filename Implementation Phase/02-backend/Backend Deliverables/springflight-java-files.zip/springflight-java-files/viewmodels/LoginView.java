package com.ensf614.springflight.viewmodels;

import lombok.Data;


@Data
public class LoginView {
    private int userID;
    private int roleID;
}
