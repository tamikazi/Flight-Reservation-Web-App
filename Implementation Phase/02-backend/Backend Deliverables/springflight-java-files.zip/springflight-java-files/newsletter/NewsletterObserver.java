package com.ensf614.springflight.newsletter;

public interface NewsletterObserver {

    void update(String newsletterContent);
}
